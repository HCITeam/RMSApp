package util.enums;

/**
 * Created by raychen on 16/5/13.
 */
public enum ResultMessage {
    SUCCESS,FAIL,NOT_FOUND
}
