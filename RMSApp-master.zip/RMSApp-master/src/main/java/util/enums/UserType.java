package util.enums;

/**
 * Created by chenm on 2016/5/9.
 */
public enum  UserType {
    User,
    Organization

}
